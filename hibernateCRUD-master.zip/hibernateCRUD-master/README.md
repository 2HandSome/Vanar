# hibernateCRUD
to test this app first of all you need to create a database named sweet
then you need to create table students  like this


+-----------+--------------+------+-----+---------+----------------+

| Field     | Type         | Null | Key | Default | Extra          |

+-----------+--------------+------+-----+---------+----------------+

| id        | int(11)      | NO   | PRI | NULL    | auto_increment |

| firstname | varchar(100) | YES  |     | NULL    |                |

| lastname  | varchar(100) | YES  |     | NULL    |                |

+-----------+--------------+------+-----+---------+----------------+

!!!! notice that you need to install jdk 10 or older not open jdk but oracle because
!!!! newest versions doesnt have non commertial javaFX support)
